const getAllPeople = () => {
    
    var pageNumber = $('#pageNumber').val();
    var pageSize = $('#pageSize').val();

    if(pageNumber >= 1 && pageSize >= 1)
    {
        $.ajax({
            // 
            url : `http://localhost:5168/Person?pageNumber=${pageNumber}&pageSize=${pageSize}`,            
            type : 'GET',        
            dataType : 'json',
                
            success : function(data) {
            // 
                $('#people-table tbody').empty();

                // 
                $.each(data, function (index, person) {
                    $('#people-table tbody').append(`
                        <tr>
                            <th scope="row">${person.businessEntityId}</th>
                            <td>${person.firstName}</td>
                            <td>${person.middleName}</td>
                            <td>${person.lastName}</td>
                            <td>${person.jobTitle}</td>
                            <td>${person.phoneNumber}</td>
                            <td>${person.city}</td>
                            <td>${person.stateProvinceName}</td>
                            <td>${person.countryRegionName}</td>
                        </tr>
                    `);
                });     
            },

            error : function(xhr, status) {
                alert('Ha ocurrido un error al obtener la información');       
            },       
        });

    }else{
        Swal.fire({
            title: "Warning",
            text: "You must enter valid values",
            icon: "warning"
        });
    }        
}